import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Activity,
} from 'lucide-react';
import axios from 'axios';


export const ClientDashboard: React.FC = () => {
  const { user } = useAuth();
  const [selectedProvider, setSelectedProvider] = useState<number>(mockProviders[0]?.id || 1);
  const [filterApplied, setFilterApplied] = useState(false);

  const userProviders = mockUserProviders.filter(up => up.user_id === user?.id);
  const currentUserProvider = userProviders.find(up => up.provider_id === selectedProvider);

  const applyFilter = () => {
    setFilterApplied(true);
  };

  const monthlyData = currentUserProvider && filterApplied
    ? calculateMonthlyConsumption(user?.id || 0, selectedProvider)
    : null;

  const last7Days = mockConsumptionHistory
    .filter(h => h.user_id === user?.id && h.provider_id === selectedProvider)
    .slice(-7);

  const maxBytes = Math.max(...last7Days.map(d => d.total_bytes), 1);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Mon Dashboard</h1>
        <p className="text-gray-500 mt-1">Suivez votre consommation internet</p>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Sélectionnez le fournisseur
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <select
            value={selectedProvider}
            onChange={(e) => {
              setSelectedProvider(Number(e.target.value));
              setFilterApplied(false);
            }}
            className="flex-1 sm:max-w-xs px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {mockProviders.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
          <button
            onClick={applyFilter}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition shadow-lg hover:shadow-xl"
          >
            Appliquer
          </button>
        </div>
      </div>

      {filterApplied && monthlyData && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <p className="text-blue-100 text-sm font-medium">Consommation Actuelle</p>
                <Activity className="w-8 h-8 text-blue-200" />
              </div>
              <p className="text-3xl font-bold">{formatBytes(monthlyData.total_consumption)}</p>
              <p className="text-blue-100 text-sm mt-1">Ce mois-ci</p>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <p className="text-green-100 text-sm font-medium">Limite Mensuelle</p>
                <CheckCircle className="w-8 h-8 text-green-200" />
              </div>
              <p className="text-3xl font-bold">{formatBytes(monthlyData.monthly_limit)}</p>
              <p className="text-green-100 text-sm mt-1">Limite définie</p>
            </div>

            <div className={`rounded-xl p-6 text-white shadow-lg ${
              monthlyData.is_exceeded
                ? 'bg-gradient-to-br from-red-500 to-red-600'
                : 'bg-gradient-to-br from-orange-500 to-orange-600'
            }`}>
              <div className="flex items-center justify-between mb-4">
                <p className={`text-sm font-medium ${
                  monthlyData.is_exceeded ? 'text-red-100' : 'text-orange-100'
                }`}>
                  Pourcentage Utilisé
                </p>
                {monthlyData.is_exceeded ? (
                  <AlertTriangle className="w-8 h-8 text-red-200" />
                ) : (
                  <TrendingUp className="w-8 h-8 text-orange-200" />
                )}
              </div>
              <p className="text-3xl font-bold">{monthlyData.percentage_used.toFixed(1)}%</p>
              <p className={`text-sm mt-1 ${
                monthlyData.is_exceeded ? 'text-red-100' : 'text-orange-100'
              }`}>
                {monthlyData.is_exceeded ? 'Limite dépassée!' : 'En cours'}
              </p>
            </div>
          </div>

          {monthlyData.is_exceeded && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-red-900">Limite dépassée</h3>
                <p className="text-sm text-red-700 mt-1">
                  Vous avez dépassé votre limite mensuelle de{' '}
                  {formatBytes(monthlyData.monthly_limit)}. Votre consommation actuelle est de{' '}
                  {formatBytes(monthlyData.total_consumption)}.
                </p>
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 mb-6">
              Graphique d'usage (7 derniers jours)
            </h2>

            <div className="space-y-4">
              {last7Days.map((day, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">
                      {new Date(day.date).toLocaleDateString('fr-FR', {
                        day: '2-digit',
                        month: 'short',
                      })}
                    </span>
                    <span className="text-sm font-semibold text-gray-900">
                      {formatBytes(day.total_bytes)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${(day.total_bytes / maxBytes) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {currentUserProvider && (
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-4">
                Informations de configuration
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Fournisseur</p>
                  <p className="font-semibold text-gray-900">
                    {currentUserProvider.provider?.name}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">IP Routeur</p>
                  <p className="font-semibold text-gray-900">{currentUserProvider.router_ip}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Statut</p>
                  <span
                    className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
                      currentUserProvider.is_active
                        ? 'bg-green-100 text-green-700'
                        : 'bg-red-100 text-red-700'
                    }`}
                  >
                    {currentUserProvider.is_active ? (
                      <>
                        <CheckCircle className="w-3 h-3" />
                        Actif
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-3 h-3" />
                        Inactif
                      </>
                    )}
                  </span>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Limite Mensuelle</p>
                  <p className="font-semibold text-gray-900">
                    {formatBytes(currentUserProvider.monthly_limit)}
                  </p>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {!filterApplied && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-8 text-center">
          <Activity className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-blue-900 mb-2">
            Sélectionnez un fournisseur
          </h3>
          <p className="text-blue-700">
            Choisissez un fournisseur et cliquez sur "Appliquer" pour voir vos statistiques.
          </p>
        </div>
      )}
    </div>
  );
};
