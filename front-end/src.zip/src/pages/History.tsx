import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  mockProviders,
  mockConsumptionHistory,
  mockUsers,
  formatBytes,
} from '../data/mockData';
import { Calendar, Download, Filter, TrendingUp } from 'lucide-react';

export const History: React.FC = () => {
  const { user } = useAuth();
  const [selectedProvider, setSelectedProvider] = useState<number>(mockProviders[0]?.id || 1);
  const [selectedUser, setSelectedUser] = useState<number>(user?.role === 'admin' ? 0 : user?.id || 0);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const isAdmin = user?.role === 'admin';
  const clientUsers = isAdmin ? mockUsers.filter(u => u.role === 'client') : [];

  let filteredHistory = mockConsumptionHistory.filter(
    h => h.provider_id === selectedProvider
  );

  if (selectedUser > 0) {
    filteredHistory = filteredHistory.filter(h => h.user_id === selectedUser);
  }

  if (startDate) {
    filteredHistory = filteredHistory.filter(h => h.date >= startDate);
  }

  if (endDate) {
    filteredHistory = filteredHistory.filter(h => h.date <= endDate);
  }

  filteredHistory.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalConsumption = filteredHistory.reduce((sum, h) => sum + h.total_bytes, 0);
  const avgDailyConsumption = filteredHistory.length > 0
    ? totalConsumption / filteredHistory.length
    : 0;

  const handleExport = () => {
    alert('Export CSV fonctionnalit\u00e9 \u00e0 impl\u00e9menter');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Historique des Consommations</h1>
          <p className="text-gray-500 mt-1">Consultez l'historique complet</p>
        </div>
        <button
          onClick={handleExport}
          className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition shadow-lg hover:shadow-xl"
        >
          <Download className="w-5 h-5" />
          Exporter CSV
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-5 h-5 text-gray-600" />
          <h2 className="text-lg font-semibold text-gray-900">Filtres</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {isAdmin && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Utilisateur
              </label>
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(Number(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={0}>Tous les utilisateurs</option>
                {clientUsers.map(u => (
                  <option key={u.id} value={u.id}>{u.username}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fournisseur
            </label>
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(Number(e.target.value))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {mockProviders.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date de d\u00e9but
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date de fin
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <p className="text-blue-100 text-sm font-medium">Consommation Totale</p>
            <TrendingUp className="w-8 h-8 text-blue-200" />
          </div>
          <p className="text-3xl font-bold">{formatBytes(totalConsumption)}</p>
          <p className="text-blue-100 text-sm mt-1">
            {filteredHistory.length} jours enregistr\u00e9s
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <p className="text-green-100 text-sm font-medium">Moyenne Journali\u00e8re</p>
            <Calendar className="w-8 h-8 text-green-200" />
          </div>
          <p className="text-3xl font-bold">{formatBytes(avgDailyConsumption)}</p>
          <p className="text-green-100 text-sm mt-1">Par jour</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">
            Historique d\u00e9taill\u00e9 ({filteredHistory.length} entr\u00e9es)
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Date
                </th>
                {isAdmin && selectedUser === 0 && (
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Utilisateur
                  </th>
                )}
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Fournisseur
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Entr\u00e9e
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Sortie
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Total
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredHistory.map((record, index) => {
                const recordUser = mockUsers.find(u => u.id === record.user_id);
                return (
                  <tr key={index} className="hover:bg-gray-50 transition">
                    <td className="px-6 py-4 text-sm text-gray-900 font-medium">
                      {new Date(record.date).toLocaleDateString('fr-FR', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </td>
                    {isAdmin && selectedUser === 0 && (
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {recordUser?.username}
                      </td>
                    )}
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {record.provider?.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {formatBytes(record.bytes_in)}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {formatBytes(record.bytes_out)}
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {formatBytes(record.total_bytes)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredHistory.length === 0 && (
          <div className="p-12 text-center">
            <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Aucun enregistrement
            </h3>
            <p className="text-gray-600">
              Aucune donn\u00e9e ne correspond \u00e0 vos crit\u00e8res de recherche.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
