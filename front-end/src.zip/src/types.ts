export type UserRole = 'admin' | 'client';
export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
}


export interface User {
  id: number;
  name: string;
  username: string;
  email: string;
  phone?: string;
  role: UserRole;
  is_active: boolean;
  profile_image?: string;
  profile_image_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Provider {
  id: number;
  name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserProvider {
  id: number;
  user_id: number;
  provider_id: number;
  router_ip: string;
  oid_byte_in: string;
  oid_byte_out: string;
  monthly_limit: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  provider?: Provider;
}

export interface ConsumptionHistory {
  id: number;
  user_id: number;
  provider_id: number;
  bytes_in: number;
  bytes_out: number;
  total_bytes: number;
  date: string;
  created_at: string;
  updated_at: string;
  provider?: Provider;
}

export interface MonthlyConsumption {
  user_id: number;
  provider_id: number;
  total_consumption: number;
  monthly_limit: number;
  percentage_used: number;
  is_exceeded: boolean;
  month: string;
  provider?: Provider;
}

export interface AuthContextType {
  user: User | null;
  isAuthLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (data: UpdateMyProfilePayload) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
}

export interface UpdateMyProfilePayload {
  name?: string;
  username?: string;
  email?: string;
  phone?: string;
  profile_image?: File | null; // upload
}