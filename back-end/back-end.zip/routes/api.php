<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ConsumptionHistoryController;
use App\Http\Controllers\ProviderController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserProviderController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function() {
    Route::get('/home', function () {
        return response()->json([
            'success' => true,
            'message' => 'API is working 🚀',
            'timestamp' => now()
        ]);
    })->name('home.api');

    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
        Route::post('/me/profile', [UserController::class, 'updateMyProfile']);
        Route::post('/me/password', [UserController::class, 'updateMyPassword']);

        Route::apiResource('users', UserController::class);


        Route::middleware('is.admin')->group(function () {
            Route::post('/users/{user}/toggle-active', [UserController::class, 'toggleActive']);
            Route::apiResource('providers', ProviderController::class);
            Route::post('/users/{user}/update-password', [UserController::class, 'updatePassword']);
        });


        Route::get('/consumption-history', [ConsumptionHistoryController::class, 'index']);
        Route::post('/consumption-history', [ConsumptionHistoryController::class, 'store']);
        Route::get('/consumption-history/monthly', [ConsumptionHistoryController::class, 'monthlyConsumption']);
        Route::get('/consumption-history/daily', [ConsumptionHistoryController::class, 'dailyConsumption']);
    });
});